class DataTypesDemo {
    public static void main(String[] args) {
        int age = 20;
        double marks = 88.5;
        char grade = 'A';
        boolean pass = true;

        System.out.println(age);
        System.out.println(marks);
        System.out.println(grade);
        System.out.println(pass);
    }
}
