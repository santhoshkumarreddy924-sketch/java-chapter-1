class ConstantExample {
    public static void main(String[] args) {
        final double PI = 3.14;
        int r = 5;
        double area = PI * r * r;

        System.out.println("Area = " + area);
    }
}
